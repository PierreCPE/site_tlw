// JSON récupérer les données:
    // Base de données
var Users = {
    User1: {
        username: "User1",
        password: "password1",
        mail: "user1@mail.com"
    },
    User2: {
        username: "User2",
        password: "password2",
        mail: "user2@mail.com"
    }
};
